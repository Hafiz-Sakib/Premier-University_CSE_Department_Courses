package javaapplication57;

interface A{
    public void run();
    public void run(int a);
    public void run(int a, float b);
}

abstract class B implements A{
    public void run()
    {
        System.out.println("Partial Implements of first methods");
    }
}

class C implements A{
    public void run()
    {
        System.out.println("1st");
        System.out.println("First method have no value");
    }
    public void run(int a)
    {
        System.out.println("2nd");
        System.out.println("Value of integer = " + a);
    }
    public void run(int a, float b)
    {
        System.out.println("3rd");
        System.out.println("Value of integer is = "+a);
        System.out.println("Value of float is = " + b);
    }
}
public class JavaApplication57 {
    public static void main(String[] args) {
        A ob = new C();
        ob.run();
        ob.run(10);
        ob.run(50, (float) 3.5);
        //A ob1 = new B();
        
        
        
    }
    
}
