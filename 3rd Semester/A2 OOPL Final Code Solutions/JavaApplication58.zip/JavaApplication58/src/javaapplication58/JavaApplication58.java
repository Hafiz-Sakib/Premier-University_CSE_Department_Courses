package javaapplication58;
import java.util.*;

public class JavaApplication58 {
    public static void main(String[] args) {
        
        //Task A
        LinkedList<String> ob = new LinkedList();
        LinkedList<String> ob2 = new LinkedList();
        ob.add(0,"Hi");
        ob.add(1,"Safiya!");
        ob.add(2,"How");
        ob.add(3,"are");
        ob.add(4,"you");
        ob.add(5,"?");       
        for(String x : ob)
        {
            System.out.println(ob.indexOf(x)+ " " + x);
        }
        System.out.println("");
        //int a = ob.indexOf("How");
        //System.out.println(ob.indexOf("How"));
        ob2.add(0,"Hello");
        ob2.add(1,"Mujib!");
        ob2.add(2,"I");
        ob2.add(3,"am");
        ob2.add(4,"fine");
        ob2.add(5,"thank");
        ob2.add(6,"you");
        for(String y : ob2)
        {
            System.out.println(ob2.indexOf(y)+ " " + y);
        }
        
        System.out.println("");
        System.out.println("");
        //Task B
        LinkedList<String> ob3 = new LinkedList();
        ob3.addAll(ob);
        ob3.addAll(ob2);
        for(String z : ob3)
        {
            System.out.println(ob3.indexOf(z)+ " " + z);
        }
        
        System.out.println("");
        System.out.println("");
        //Task C
        boolean t;
        t = ob.contains("Safiya");
        System.out.println(t);
        
        
        System.out.println("");
        System.out.println("");
        //Task D
        ob3.removeAll(ob3);
        ob3.add("JAVA Programming");
        for(String z : ob3)
        {
            System.out.println("After remove");
            System.out.println(ob3.indexOf(z)+ " " + z);
        }
    }    
}
