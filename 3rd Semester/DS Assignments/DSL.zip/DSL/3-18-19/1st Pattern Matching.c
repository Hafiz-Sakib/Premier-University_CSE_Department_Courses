#include<stdio.h>
main()
{
    char T[100], p[100];
    printf("Enter the text: ");
    gets(T);
    int Tlen=strlen(T);
    printf("Enter the Pattern: ");
    gets(p);
    int Plen=strlen(p);
    int i,j,count=0;
    for(i=0;i<Tlen-Plen;i++)
    {
        for(j=0;j<Plen;j++)
        {
            if(T[i+j]!=p[j])
            {
                break;
            }
        }
        if(j>=plen)
            count=count+1'

    }
    printf("The position is %d",count);
    return 0;
}
