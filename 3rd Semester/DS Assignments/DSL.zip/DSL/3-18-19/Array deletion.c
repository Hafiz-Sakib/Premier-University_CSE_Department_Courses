#include<stdio.h>
main()
{
    int n;
    printf("How Many Number?\n");
    scanf("%d",&n);
    int num[n+5],k,i,j;
    printf("Which position number?\n");
}
