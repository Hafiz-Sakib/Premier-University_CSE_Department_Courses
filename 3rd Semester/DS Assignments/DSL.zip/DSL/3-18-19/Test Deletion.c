#include<stdio.h>
main()
{
    char T[100],T2[100];
    int pos,len;
    printf("Enter the text\n");
    gets(T);
    int Tlen=strlen(T);
    printf("Enter the position\n");
    scanf("%d",&pos);
    printf("Enter the Length\n");
    scanf("%d",&len);
    int j=0;
    for(int i=0;i<pos-1;i++)
    {
        T2[j]= T[i];
        j++;
    }
    for(int i=Tlen-pos-1;i<=Tlen;i++)
    {
        T2[j]=T[i];
        j++;
    }
    printf("After Deletion the text : ");
    puts(T2);

    return 0;
}
