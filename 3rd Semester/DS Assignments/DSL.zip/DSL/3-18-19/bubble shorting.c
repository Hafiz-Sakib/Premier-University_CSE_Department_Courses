#include<stdio.h>
main()
{

    int n;
    printf("How Many number?\n");
    scanf("%d",&n);
    int k[n+5];
    for(int i=0;i<n;i++)
        scanf("%d",&k[i]);
    int i,j,temp;
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
    {
        if(k[j]>k[j+1])
        {
            temp=k[j+1];
            k[j+1]=k[j];
            k[j]=temp;
        }
    }
    for(i=0;i<n;i++)
        printf("%d ",k[i]);
    return 0;
}
