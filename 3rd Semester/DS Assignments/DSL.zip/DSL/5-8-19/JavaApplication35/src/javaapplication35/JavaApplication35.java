package javaapplication35;

import java.util.*;

public class JavaApplication35 {

    public static void main(String[] args) {
        List<String> words = new ArrayList<String>();
        
        words.add("Hi");
        words.add("How");
        words.add("Are");
        words.add("You");
        words.add("");
        
        int a = words.size();
        System.out.println("The size of words: " + a);
         System.out.println("\n");
        
        int length = 0;
    for(String temp : words)
    {
        length = length+ temp.length();
        System.out.print(temp + " " );
        
    }
        System.out.println("\n");
        System.out.println("\nThe length is: " + length);
        
        System.out.println("\n");
        
        String str= words.get(0);
        System.out.println("Index no 0: " + str);
        words.set (0,"Hello");
        words.set (1,"I");
        words.set (2,"Am");
        words.set (3,"Fine");
        words.set (4,"");
        System.out.println("\n");
    for(String temp : words)
    {
        length = length+ temp.length();
        System.out.print(temp + " " );
        
    }
        System.out.println("\n");
    
        words.remove(3);
    
    for(String temp : words)
    {
        length = length+ temp.length();
        System.out.print(temp + " " );
        
    }
        System.out.println("\n");
        words.add("Not Fine");
    
    for(String temp : words)
    {
        length = length+ temp.length();
        System.out.print(temp + " " );
        
    }
        System.out.println("\n");
    
    
    int size = words.size();
        System.out.println("The sizew of words: " + size);
    
        System.out.println("\n");
    
    
        System.out.println(words);
        
        System.out.println("\n");
        
        List sub = words.subList(1, 5);
        int size2 = sub.size();
        System.out.println("Size of Sub List: "+ size2);
        System.out.println("The sub list:\n"+ sub);
        
        sub.clear();
        System.out.println(sub);
    
    
    
        
        
    
    }  
    
    
}
