package javaapplication36;

import java.util.*;
//import java.util.Scanner;

public class JavaApplication36 {

    public static void main(String[] args) {
        Scanner n = new Scanner(System.in);
        Scanner s =  new Scanner(System.in);
        List<String> words = new ArrayList<String>();
        
        while(true)
        {
            System.out.println("What do you you want?");
        System.out.println("1. Add\n2. Remove\n3. Print String\n4.Size of String");
        int input = n.nextInt();
        if( input ==1)
        {
            System.out.println("Input a word");
            String a = s.nextLine();
            words.add(a);
            
        }
        else if(input == 2)
        {
            System.out.println("How you want to delete?");
            System.out.println("1. By index number\n2. By singel word");
            int temp = n.nextInt();
            if(temp == 1)
            {
                System.out.println("Input the Index number: ");
                int temp2 = n.nextInt();
                words.remove(temp2);
            }
            else if(temp==2)
            {
                System.out.println("Input your String: ");
                String temp3 = s.nextLine();
                words.remove(temp3);
            }
            else
                System.out.println("\nWrong Input\n");
            
            
            
        }
        else if(input ==3)
        {
            System.out.println("\n\n");
            System.out.println(words);
            System.out.println("\n\n");
        }
        else if(input == 4)
        {
            int temp4 = words.size();
            System.out.println("\n\n");
            System.out.println(temp4);
            System.out.println("\n\n");
            
        }
        else
            System.out.println("\nWrong Input\n");
        
        }
    }
    
}
