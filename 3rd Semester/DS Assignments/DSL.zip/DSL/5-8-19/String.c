#include<stdio.h>
main()
{
    char Name[100][30];
    int n,i,j;
    printf("How Many Names?\n");
    scanf("%d",&n);
    getchar();

    char x[100][100];
    for(i=0;i<n;i++)
    {
        printf("\nEnter %d person name: ",i+1);
        scanf("%[^\n]",&Name[i]);
        getchar();
    }

    printf("\n\nYour Entered Names Are:\n");
    for(i=0;i<n;i++)
    {
         printf("\nPerson %d name: ",i+1);
         //printf("%s",Name[i]);
         x[i]= Name[i];
    }

    printf("\n\n\n");
    printf("%s",Name[0]);
    return 0;

}
