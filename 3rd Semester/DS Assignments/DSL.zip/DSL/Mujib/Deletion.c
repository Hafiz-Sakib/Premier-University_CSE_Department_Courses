#include<stdio.h>
main()
{
    int LA[1000],i=1,n,k,item;
    printf("How many digit?\n");
    scanf("%d",&n);
    printf("Enter the numbers: \n");
    while(i<=n)
    {
        scanf("%d",&LA[i]);
        i++;
    }
    printf("Enter the position\n");
    scanf("%d",&k);
    int j;
    item=LA[k];
    for(j=k;j<=n-1;j++)
        LA[j]=LA[j+1];
    n=n-1;
    printf("The Series after DELETION: \n");
    for(i=1;i<=n;i++)
        printf("%d\t",LA[i]);
    return 0;
}
