#include<stdio.h>
main()
{
    int k,a[1000],n;
    printf("How many digit?\n");
    scanf("%d",&n);
    int i=1;
    printf("Enter the numbers: \n");
    while(i<=n)
    {
        scanf("%d",&a[i]);
        i++;
    }
    a[0]=-9999;
    int ptr,temp;
    for(k=2;k<=n;k++)
    {
        temp=a[k];
        ptr=k-1;
        while(temp<a[ptr])
        {
            a[ptr+1]=a[ptr];
            ptr=ptr-1;
        }
        a[ptr+1]=temp;
    }
    printf("The series after INSERTION SORT:\n");
    for(int l=1;l<=n;l++)
        printf("%d\t",a[l]);
    return 0;
}
