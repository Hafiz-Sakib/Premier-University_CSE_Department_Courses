#include<stdio.h>
main()
{
    int n,DATA[1000],i=1,item;
    printf("How many digit?\n");
    scanf("%d",&n);
    printf("Enter the numbers: \n");
    while(i<=n)
    {
        scanf("%d",&DATA[i]);
        i++;
    }
    printf("Enter the ITEM\n");
    scanf("%d",&item);
    int LOC;
//    printf("What is the location of the ITEM?\n");
//    scanf("%d",&LOC);
    DATA[n+1]=item;
    LOC=1;
    while(DATA[LOC]!= item)
    {
        LOC++;
    }
    if(LOC==n+1)
    {
        LOC=0;
        printf("The number isn't found\n");
    }
    else
        printf("The location of this number is %d",LOC);

    return 0;

}
