#include<stdio.h>
main()
{
    int DATA[100],i=1,j,n,k,ptr;
    printf("How many digit?\n");
    scanf("%d",&n);
    printf("Enter the numbers: \n");
    while(i<=n)
    {
        scanf("%d",&DATA[i]);
        i++;
    }
    int temp;
    for(k=1;k<=n-1;k++)
    {
        ptr=1;
        while(ptr<=n-k)
        {
            if(DATA[ptr]>DATA[ptr+1])
                {
                    temp=DATA[ptr];
                    DATA[ptr]=DATA[ptr+1];
                    DATA[ptr+1]=temp;

                }

            ptr=ptr+1;

        }
    }
    for(j=1;j<=n;j++)
        printf("%d\t",DATA[j]);
    return 0;
}
