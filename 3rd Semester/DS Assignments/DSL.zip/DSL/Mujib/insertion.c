#include<stdio.h>
main()
{
    int i=1,LA[1000],n,K,item;
    printf("How many digit?\n");
    scanf("%d",&n);
    printf("Enter the numbers: \n");
    while(i<=n)
    {
        scanf("%d",&LA[i]);
        i++;
    }
    int k;
    printf("Enter the position\n");
    scanf("%d",&k);
    k=k;
    printf("Enter the number that you want to INSERT\n");
    scanf("%d",&item);
    int j = n;
    while(j>=k)
    {
        LA[j+1]=LA[j];
        j--;
    }
    LA[k]=item;
    n=n+1;

    printf("The number series after INSERTION: \n");
    i=1;
    while(i<n)
    {
        printf("%d\t",LA[i]);
        i++;
    }
    return 0;
}
