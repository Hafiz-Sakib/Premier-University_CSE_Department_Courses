#include<stdio.h>
#define MAX 100
main()
{
    int item, Q[MAX], r=5, f=0;
    Q[0]=10;
    Q[1]=20;
    Q[2]=30;
    Q[3]=40;
    Q[4]=50;
    Q[5]=60;

    int n,i=0;
    printf("How many delete?\n");
    scanf("%d",&n);

    printf("Deleted elements from Queue: ");
    while(n--)
    {
        if(f == -1 || f>r)
        {
            printf("Queue Underflow");
        }
        else
        {
            printf("%d ",Q[f]);
            f++;
        }
    }
    return 0;
}
