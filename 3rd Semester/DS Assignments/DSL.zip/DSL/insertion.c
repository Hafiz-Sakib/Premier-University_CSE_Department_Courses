#include<stdio.h>
#define MAX 100
main()
{
    int item, Q[MAX], r=-1, f=-1;
    int n,i=0;
    printf("How many elements?");
    scanf("%d",&n);
    while(i<n)
    {
        if(r== (MAX-1) )
        {
            printf("Queue Overflow\n");
            break;
        }
        else
        {
            if(f == -1)
                f =0;
            printf("\nEnter Queue element: ");
            scanf("%d",&item);
            r = r+1;
            Q[r]= item;
        }
        printf("\n%d elements are: ",i+1);
        for(int j=0;j<=i;j++)
        {
            printf("%d ",Q[j]);
        }
        i++;

    }
    printf("\n\nR = %d\nF = %d",r,f);
    return 0;
}
