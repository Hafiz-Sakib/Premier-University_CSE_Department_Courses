#include<stdio.h>
#define MAX 100
main()
{
    int item, Q[MAX], r=5, f=0;
    Q[0]=10;
    Q[1]=20;
    Q[2]=30;
    Q[3]=40;
    Q[4]=50;
    Q[5]=60;
    Q[6]=70;
    Q[7]=80;
    Q[8]=90;
    Q[9]=100;

    printf("Traversing in inserted Queue:\n");
    int n=0;
    while(n<10)
    {
        printf("Elements %d is %d\n",n+1,Q[n]);
        n++;
    }
    return 0;
}
